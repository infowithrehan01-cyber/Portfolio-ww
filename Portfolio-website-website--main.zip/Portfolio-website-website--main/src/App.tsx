import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Skills } from './components/Skills';
import { Projects } from './components/Projects';
import { Services } from './components/Services';
import { Experience } from './components/Experience';
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { ResumeModal } from './components/ResumeModal';
import { Toast } from './components/Toast';

export default function App() {
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('rehan_portfolio_theme');
    if (saved !== null) {
      return saved === 'dark';
    }
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  const [resumeOpen, setResumeOpen] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
      localStorage.setItem('rehan_portfolio_theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('rehan_portfolio_theme', 'light');
    }
  }, [darkMode]);

  const showToast = (message: string, type: 'success' | 'error') => {
    setToast({ message, type });
  };

  return (
    <div className="min-h-screen bg-[#F3F7FD] dark:bg-[#0B1120] text-slate-800 dark:text-slate-100 transition-colors duration-300 font-['Plus_Jakarta_Sans',sans-serif] relative selection:bg-blue-600 selection:text-white overflow-x-hidden">
      {/* Background Soft Gradients */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-200/30 dark:bg-blue-900/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 left-0 w-[500px] h-[500px] bg-sky-200/30 dark:bg-sky-900/10 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10">
        {/* Sticky Header */}
        <Navbar
          darkMode={darkMode}
          setDarkMode={setDarkMode}
          onOpenResume={() => setResumeOpen(true)}
        />

        {/* Hero Section */}
        <main>
          <Hero onOpenResume={() => setResumeOpen(true)} />
          <About onOpenResume={() => setResumeOpen(true)} />
          <Skills />
          <Projects />
          <Services />
          <Experience />
          <Testimonials />
          <Contact onShowToast={showToast} />
        </main>

        {/* Footer */}
        <Footer />
      </div>

      {/* Resume Viewer Modal */}
      <ResumeModal
        isOpen={resumeOpen}
        onClose={() => setResumeOpen(false)}
        onShowToast={showToast}
      />

      {/* Interactive Toast Notification */}
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}
