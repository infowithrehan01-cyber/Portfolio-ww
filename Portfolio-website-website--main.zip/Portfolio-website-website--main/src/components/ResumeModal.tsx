import React from 'react';
import { X, Download, FileText, Mail, Phone, MapPin, Globe, CheckCircle2 } from 'lucide-react';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (message: string, type: 'success' | 'error') => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose, onShowToast }) => {
  if (!isOpen) return null;

  const handleDownloadPDF = () => {
    const link = document.createElement('a');
    link.href = '/Muhammad-Rehan-CV.pdf';
    link.download = 'Muhammad-Rehan-CV.pdf';
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    onShowToast('Muhammad Rehan CV downloaded successfully!', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl bg-white dark:bg-slate-900 border border-blue-100 dark:border-slate-800 shadow-2xl p-6 sm:p-10 space-y-8">

        {/* Modal Top Bar */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-5">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-600 text-white shadow-md shadow-blue-500/20">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white font-heading">
                Muhammad Rehan's Curriculum Vitae
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Official AI & Full-Stack Web Developer CV
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="/Muhammad-Rehan-CV.pdf"
              download="Muhammad-Rehan-CV.pdf"
              target="_blank"
              rel="noreferrer"
              onClick={() => onShowToast('Muhammad Rehan CV downloaded successfully!', 'success')}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-500/20"
            >
              <Download className="w-4 h-4" />
              <span>Download CV</span>
            </a>

            <button
              onClick={onClose}
              className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Resume Sheet Preview */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-6 text-slate-800 dark:text-slate-100">

          {/* Resume Header */}
          <div className="border-b border-slate-200 dark:border-slate-700 pb-6 space-y-2">
            <h1 className="text-3xl font-extrabold font-heading text-slate-900 dark:text-white">Muhammad Rehan</h1>
            <h2 className="text-base font-bold text-blue-600 dark:text-blue-400">AI Developer & Full-Stack Web Developer</h2>
            <div className="flex flex-wrap gap-x-6 gap-y-1 text-xs text-slate-600 dark:text-slate-300 pt-1">
              <a href="mailto:infowithrehan01@gmail.com" className="flex items-center gap-1 hover:underline"><Mail className="w-3.5 h-3.5 text-blue-600" /> infowithrehan01@gmail.com</a>
              <a href="https://wa.me/923026533848" target="_blank" rel="noreferrer" className="flex items-center gap-1 hover:underline"><Phone className="w-3.5 h-3.5 text-blue-600" /> 03026533848</a>
              <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-blue-600" /> Haroonabad, Pakistan</span>
            </div>
          </div>

          {/* Summary */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">About Me</h3>
            <p className="text-xs sm:text-sm leading-relaxed text-slate-700 dark:text-slate-300 italic bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
              “I’m Muhammad Rehan, an AI Developer and Full-Stack Web Developer with 6 months of hands-on experience. I enjoy building modern, responsive websites and AI-powered digital solutions. I focus on clean design, practical functionality, responsive user experiences and continuously improving my development skills.”
            </p>
          </div>

          {/* Technical Skills */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">Technical Skills</h3>
            <div className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-xs leading-relaxed">
              HTML5, CSS3, JavaScript, AI / AI Tools, Git & GitHub, React, Node.js, Express.js, MongoDB, MySQL, Firebase, Tailwind CSS, REST APIs, Responsive Web Design
            </div>
          </div>

          {/* Experience */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">Development Experience</h3>

            <div className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1 text-xs">
              <div className="flex justify-between font-bold text-slate-900 dark:text-white">
                <span>AI Developer & Full-Stack Web Developer</span>
                <span className="text-blue-600 dark:text-blue-400">6 Months Experience</span>
              </div>
              <p className="text-slate-600 dark:text-slate-300 pt-1">Developed 8 web applications and AI digital solutions focusing on clean design, responsive interfaces, and practical functionality.</p>
            </div>
          </div>

          {/* Education */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">Education</h3>
            <div className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3 text-xs">
              <div>
                <div className="font-bold text-slate-900 dark:text-white">BS Computer Science (BSCS)</div>
                <div className="text-slate-500">Government Degree College, Haroonabad</div>
              </div>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-700">
                <div className="font-bold text-slate-900 dark:text-white">F.Sc.</div>
                <div className="text-slate-500">Government Degree College, Haroonabad</div>
              </div>
            </div>
          </div>

        </div>

        {/* Action Footer */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold text-xs sm:text-sm"
          >
            Close
          </button>
          <a
            href="/Muhammad-Rehan-CV.pdf"
            download="Muhammad-Rehan-CV.pdf"
            target="_blank"
            rel="noreferrer"
            onClick={() => onShowToast('Muhammad Rehan CV downloaded successfully!', 'success')}
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-500/20 flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>Download PDF CV</span>
          </a>
        </div>

      </div>
    </div>
  );
};

