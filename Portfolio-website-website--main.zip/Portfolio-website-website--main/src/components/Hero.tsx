import React, { useState, useEffect } from 'react';
import { Code2, Send, Mail, Github, Facebook, Instagram, Calendar, TrendingUp, Briefcase, Star, ChevronLeft, ChevronRight, CheckCircle2, Download, MapPin, Phone } from 'lucide-react';
import rehanProfilePng from '../assets/images/rehan-profile.png';
import rehanProfileJpg from '../assets/images/rehan-profile.jpg';

interface HeroProps {
  onOpenResume: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenResume }) => {
  // Rotating typing titles list requested by user
  const titles = [
    'AI Developer & Full-Stack Web Developer',
    'Full-Stack Developer',
    'Frontend Developer',
    'Backend Developer',
    'Web Developer',
    'JavaScript Developer',
    'React Developer',
  ];

  // Typing animation state with guaranteed smooth cycle and zero cutoff
  const [currentTitleIndex, setCurrentTitleIndex] = useState(0);
  const [currentText, setCurrentText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [imgSrc, setImgSrc] = useState<string>(rehanProfilePng);

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    const currentFullTitle = titles[currentTitleIndex];

    if (isDeleting) {
      if (currentText.length > 0) {
        timeout = setTimeout(() => {
          setCurrentText(currentFullTitle.slice(0, currentText.length - 1));
        }, 35);
      } else {
        setIsDeleting(false);
        setCurrentTitleIndex((prev) => (prev + 1) % titles.length);
      }
    } else {
      if (currentText.length < currentFullTitle.length) {
        timeout = setTimeout(() => {
          setCurrentText(currentFullTitle.slice(0, currentText.length + 1));
        }, 70);
      } else {
        timeout = setTimeout(() => {
          setIsDeleting(true);
        }, 1800);
      }
    }

    return () => clearTimeout(timeout);
  }, [currentText, isDeleting, currentTitleIndex]);

  // Calendar state matching current month
  const [selectedDate, setSelectedDate] = useState(7);
  const [currentMonth, setCurrentMonth] = useState('October 2026');

  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const calendarDays = [5, 6, 7, 8, 9, 10, 11];

  return (
    <section id="home" className="relative pt-24 pb-16 lg:pt-32 lg:pb-24 overflow-hidden">
      {/* Background Soft Blue Glow Effect */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] sm:w-[800px] h-[400px] sm:h-[500px] bg-gradient-to-tr from-blue-200/40 via-sky-100/30 to-indigo-100/20 dark:from-blue-950/30 dark:via-sky-950/20 dark:to-slate-900/0 rounded-full blur-3xl -z-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-8 items-center">

          {/* Left Column - Hero Content (5 cols) */}
          <div className="lg:col-span-5 space-y-6 text-center lg:text-left">
            {/* Status Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100/90 dark:bg-blue-950/90 border border-blue-200 dark:border-blue-800/80 text-blue-700 dark:text-blue-300 text-xs font-bold uppercase tracking-wider shadow-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Haroonabad, Pakistan · Open for work</span>
            </div>

            {/* Headline Title */}
            <div className="space-y-1">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-tight">
                Hi, I’m
                <span className="block text-blue-600 dark:text-blue-500 font-extrabold text-3xl sm:text-4xl lg:text-5xl mt-1 tracking-tight">
                  Muhammad Rehan
                </span>
              </h1>

              {/* Animated Typing Role Title */}
              <div className="h-12 sm:h-14 flex items-center justify-center lg:justify-start overflow-hidden">
                <span className="text-lg sm:text-xl lg:text-2xl font-bold text-slate-800 dark:text-slate-100 font-heading">
                  {currentText}
                  <span className="inline-block w-0.5 h-6 sm:h-7 ml-1 bg-blue-600 dark:bg-blue-400 animate-pulse align-middle" />
                </span>
              </div>
            </div>

            {/* Intro Paragraph */}
            <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base max-w-xl mx-auto lg:mx-0 font-normal leading-relaxed">
              I’m an AI Developer and Full-Stack Web Developer focused on building modern, responsive websites and AI-powered digital solutions.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3.5 pt-1">
              <a
                href="/Muhammad-Rehan-CV.pdf"
                download="Muhammad-Rehan-CV.pdf"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-lg shadow-blue-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Download className="w-4 h-4" />
                <span>Download CV</span>
              </a>

              <a
                href="#projects"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 font-semibold text-sm shadow-xs transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Send className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>View Projects</span>
              </a>
            </div>

            {/* Social Media Links */}
            <div className="flex items-center justify-center lg:justify-start gap-4 pt-2">
              {[
                { name: 'GitHub', icon: Github, href: 'https://github.com/infowithrehan01-cyber' },
                { name: 'Facebook', icon: Facebook, href: 'https://www.facebook.com/share/1cVzLtmtvV/' },
                { name: 'Instagram', icon: Instagram, href: 'https://www.instagram.com/chrehan89761437?stkn=b2E3NXhtdTV5ZmVi' },
              ].map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noreferrer"
                  className="w-10 h-10 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:border-blue-300 dark:hover:border-blue-600 shadow-2xs hover:scale-110 transition-all"
                  aria-label={social.name}
                >
                  <social.icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Center Column - Portrait Card with exact uploaded profile photo (4 cols) */}
          <div className="lg:col-span-4 flex justify-center">
            <div className="relative group w-full max-w-[280px] sm:max-w-[320px] lg:max-w-[360px]">
              {/* Outer soft shadow aura */}
              <div className="absolute -inset-1.5 bg-gradient-to-r from-blue-500/30 via-sky-400/20 to-indigo-500/30 dark:from-blue-600/40 dark:to-indigo-600/40 rounded-[2.2rem] blur-xl opacity-40 group-hover:opacity-75 transition duration-500" />

              {/* Portrait Container */}
              <div className="relative rounded-[2rem] overflow-hidden border-4 border-white dark:border-slate-800 bg-slate-900 shadow-2xl transition-transform duration-300 group-hover:scale-[1.01]">
                <img
                  src={imgSrc}
                  onError={() => setImgSrc(rehanProfileJpg)}
                  alt="Muhammad Rehan - AI & Full-Stack Web Developer"
                  className="w-full h-[320px] sm:h-[390px] lg:h-[430px] object-cover object-top"
                />

                {/* Subtle scrim overlay at bottom */}
                <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-slate-950/85 via-slate-950/30 to-transparent flex items-end justify-between p-4 text-white">
                  <div>
                    <div className="font-bold text-sm tracking-tight">Muhammad Rehan</div>
                    <div className="text-[11px] text-blue-300 font-medium">AI & Full-Stack Developer</div>
                  </div>
                  <div className="flex items-center gap-1 bg-emerald-500/20 backdrop-blur-md px-2 py-0.5 rounded-full border border-emerald-400/30 text-[10px] text-emerald-300 font-semibold">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>Verified</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Real Info & Quick Contacts (3 cols) */}
          <div className="lg:col-span-3 space-y-4">

            {/* Quick Contact Widget */}
            <div className="p-4 sm:p-5 rounded-2xl bg-white/95 dark:bg-slate-800/95 backdrop-blur-md border border-blue-100 dark:border-slate-700 shadow-md shadow-blue-500/5 hover:border-blue-300 dark:hover:border-blue-600 transition-all space-y-3">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400">
                  <MapPin className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">Location</h3>
                  <div className="text-xs text-slate-600 dark:text-slate-300">Haroonabad, Pakistan</div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-700 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400">
                  <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">Phone / WhatsApp</h3>
                  <a href="https://wa.me/923026533848" target="_blank" rel="noreferrer" className="text-xs text-blue-600 dark:text-blue-400 hover:underline">03026533848</a>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-700 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400">
                  <Mail className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">Email</h3>
                  <a href="mailto:infowithrehan01@gmail.com" className="text-xs text-blue-600 dark:text-blue-400 hover:underline truncate block max-w-[170px]">infowithrehan01@gmail.com</a>
                </div>
              </div>
            </div>

            {/* Statistics Card */}
            <div className="p-4 sm:p-5 rounded-2xl bg-white/95 dark:bg-slate-800/95 backdrop-blur-md border border-blue-100 dark:border-slate-700 shadow-md shadow-blue-500/5 space-y-3.5">
              {/* Stat 1 */}
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-xl bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400 shrink-0">
                  <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div>
                  <div className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white font-heading">6 Months</div>
                  <div className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium">Hands-on experience</div>
                </div>
              </div>

              {/* Stat 2 */}
              <div className="flex items-start gap-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                <div className="p-2 rounded-xl bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400 shrink-0">
                  <Briefcase className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div>
                  <div className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white font-heading">8 Projects</div>
                  <div className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium">Full-stack & AI applications</div>
                </div>
              </div>

              {/* Stat 3 */}
              <div className="flex items-start gap-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                <div className="p-2 rounded-xl bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400 shrink-0">
                  <Star className="w-4 h-4 sm:w-5 sm:h-5 fill-amber-400 text-amber-400" />
                </div>
                <div>
                  <div className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white font-heading">Clean Design</div>
                  <div className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium">Practical & responsive websites</div>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};


