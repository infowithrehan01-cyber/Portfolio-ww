import React, { useState } from 'react';
import { ExternalLink, Github, Eye, Sparkles, X, Check, Layers } from 'lucide-react';

import imgSaas from '../assets/images/project_saas_dashboard_1791364977812.jpg';
import imgEcommerce from '../assets/images/project_ecommerce_app_1791364992894.jpg';
import imgMobileFitness from '../assets/images/project_mobile_fitness_1791365027077.jpg';
import imgAiWorkspace from '../assets/images/project_ai_workspace_1791365014292.jpg';

export interface Project {
  id: string;
  title: string;
  category: 'fullstack' | 'frontend' | 'ecommerce' | 'ai';
  image: string;
  description: string;
  longDescription: string;
  tags: string[];
  githubUrl: string;
  keyFeatures: string[];
}

export const Projects: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'fullstack' | 'frontend' | 'ecommerce' | 'ai'>('all');
  const [activeProjectModal, setActiveProjectModal] = useState<Project | null>(null);

  const projects: Project[] = [
    {
      id: 'medical-college',
      title: 'Medical College Website',
      category: 'fullstack',
      image: imgSaas,
      description: 'Official academic web portal for medical students, department directory, research publications, and course curriculum.',
      longDescription: 'A comprehensive web platform built for a medical institute. It includes faculty directories, research publication repositories, student department schedules, and online admission inquiry workflows.',
      tags: ['React', 'Node.js', 'Express', 'MongoDB', 'Tailwind CSS'],
      githubUrl: 'https://github.com/infowithrehan01-cyber',
      keyFeatures: [
        'Faculty and student department directory with searchable profiles',
        'Academic publication catalog and research paper archives',
        'Responsive mobile-first navigation and contact forms',
      ],
    },
    {
      id: 'bakery-sweets',
      title: 'Bakery & Sweets Website',
      category: 'ecommerce',
      image: imgEcommerce,
      description: 'Online bakery and confectionery shop with product catalogs, custom order inquiry, and interactive product gallery.',
      longDescription: 'An e-commerce destination crafted for an artisan bakery. Features interactive cake customization preview, product filtering by flavor and dietary preferences, and order inquiry checkout.',
      tags: ['React', 'Tailwind CSS', 'Node.js', 'Express', 'JavaScript'],
      githubUrl: 'https://github.com/infowithrehan01-cyber',
      keyFeatures: [
        'Custom cake and sweet customization options',
        'Interactive shopping cart drawer with local delivery scheduling',
        'High-resolution product showcase and user review grid',
      ],
    },
    {
      id: 'pharmacy-store',
      title: 'Pharmacy / Medical Store Website',
      category: 'fullstack',
      image: imgMobileFitness,
      description: 'Healthcare e-commerce and medical store platform for prescription medicines, OTC products, and order tracking.',
      longDescription: 'An intuitive online pharmacy application allowing users to search health products, browse medicine categories, upload doctor prescriptions, and track home deliveries.',
      tags: ['React', 'Node.js', 'Express.js', 'MongoDB', 'REST APIs'],
      githubUrl: 'https://github.com/infowithrehan01-cyber',
      keyFeatures: [
        'Prescription upload workflow with pharmacist review pipeline',
        'Faceted medicine category search by manufacturer and dosage',
        'Responsive mobile interface for quick medicine re-ordering',
      ],
    },
    {
      id: 'doctor-services',
      title: 'Doctor Services Website',
      category: 'fullstack',
      image: imgAiWorkspace,
      description: 'Healthcare appointment booking portal with specialist doctor search, consultation scheduling, and clinic records.',
      longDescription: 'A modern medical booking application connecting patients with specialist physicians. Integrates appointment slot reservation, doctor profile directories, and digital confirmation tickets.',
      tags: ['React', 'Node.js', 'Express.js', 'MySQL', 'Tailwind CSS'],
      githubUrl: 'https://github.com/infowithrehan01-cyber',
      keyFeatures: [
        'Interactive doctor directory filterable by specialty and location',
        'Real-time appointment slot reservation and calendar scheduling',
        'Doctor schedule management dashboard and patient logs',
      ],
    },
    {
      id: 'novamobile-store',
      title: 'NovaMobile Website',
      category: 'ecommerce',
      image: imgEcommerce,
      description: 'Smartphone & tech gadget storefront with side-by-side device specification comparison and accessory store.',
      longDescription: 'A high-performance e-commerce platform for smartphones and mobile gadgets. Features device spec comparison tables, brand filtering, customer ratings, and responsive mobile shopping cart.',
      tags: ['React', 'Node.js', 'Express.js', 'MongoDB', 'Tailwind CSS'],
      githubUrl: 'https://github.com/infowithrehan01-cyber',
      keyFeatures: [
        'Side-by-side smartphone spec comparison (RAM, battery, camera, price)',
        'Faceted product search filterable by brand, OS, and price range',
        'Optimized mobile cart and guest checkout workflow',
      ],
    },
    {
      id: 'gym-website',
      title: 'Gym Website',
      category: 'frontend',
      image: imgMobileFitness,
      description: 'Fitness club & gym portal featuring workout plans, trainer directories, class schedules, and membership packages.',
      longDescription: 'A dynamic web application designed for a modern fitness center. Includes interactive workout schedule tables, personal trainer bios, membership tier pricing cards, and lead booking forms.',
      tags: ['React', 'JavaScript', 'Tailwind CSS', 'Responsive Web Design'],
      githubUrl: 'https://github.com/infowithrehan01-cyber',
      keyFeatures: [
        'Interactive weekly workout class schedule filterable by activity',
        'Trainer profile gallery with specialized fitness certifications',
        'Membership package selector with direct sign-up inquiry',
      ],
    },
    {
      id: 'tailor-app',
      title: 'Tailor App',
      category: 'fullstack',
      image: imgSaas,
      description: 'Custom tailoring management app for client measurements, suit/dress design customization, and order status tracking.',
      longDescription: 'A specialized web application for bespoke tailors and clothing boutiques. Allows tailors to record precise client measurements, manage order stages, and provide order status tracking.',
      tags: ['React', 'Node.js', 'Express.js', 'MongoDB', 'Tailwind CSS'],
      githubUrl: 'https://github.com/infowithrehan01-cyber',
      keyFeatures: [
        'Client body measurement logging and order history database',
        'Custom suit/dress fabric and design selection options',
        'Order status pipeline tracking (Stitching, Fitting, Ready)',
      ],
    },
    {
      id: 'personal-portfolio',
      title: 'Personal Portfolio Website',
      category: 'ai',
      image: imgAiWorkspace,
      description: 'Official developer portfolio highlighting AI projects, full-stack web applications, resume download, and contact details.',
      longDescription: 'My official developer portfolio website showcasing my projects, technical skill stack, academic background, and real contact information. Designed with modern dark blue aesthetic and full responsiveness.',
      tags: ['React', 'TypeScript', 'Tailwind CSS', 'AI Tools', 'HTML5', 'CSS3'],
      githubUrl: 'https://github.com/infowithrehan01-cyber',
      keyFeatures: [
        'Typewriter title animation and dark/light theme persistence',
        'Download CV integration with real PDF asset',
        'Fully responsive mobile drawer navigation and copy-to-clipboard actions',
      ],
    },
  ];

  const filteredProjects = selectedCategory === 'all'
    ? projects
    : projects.filter((p) => p.category === selectedCategory);

  const filterTabs = [
    { id: 'all', label: 'All Projects (8)' },
    { id: 'fullstack', label: 'Full-Stack' },
    { id: 'ecommerce', label: 'E-Commerce' },
    { id: 'frontend', label: 'Frontend' },
    { id: 'ai', label: 'AI & Web' },
  ];

  return (
    <section id="projects" className="py-20 lg:py-28 bg-white/60 dark:bg-slate-900/40 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
            <Layers className="w-4 h-4" />
            <span>PORTFOLIO SHOWCASE</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white font-heading tracking-tight">
            My <span className="text-blue-600 dark:text-blue-500">Projects</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg leading-relaxed">
            All 8 web applications and AI digital solutions I have developed.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 max-w-xl mx-auto mb-10 p-1.5 bg-white dark:bg-slate-800 rounded-2xl border border-blue-100 dark:border-slate-700 shadow-sm">
          {filterTabs.map((tab) => {
            const isActive = selectedCategory === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setSelectedCategory(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-500/25'
                    : 'text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="rounded-3xl bg-white dark:bg-slate-800/90 border border-blue-100 dark:border-slate-700 shadow-lg shadow-blue-500/5 hover:shadow-2xl hover:border-blue-300 dark:hover:border-blue-600 transition-all duration-300 overflow-hidden flex flex-col group"
            >
              {/* Project Image Container */}
              <div className="relative h-52 sm:h-56 overflow-hidden bg-slate-900">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />

                {/* Category Badge */}
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-white/90 dark:bg-slate-900/90 backdrop-blur-md text-blue-600 dark:text-blue-400 shadow-sm">
                    {project.category.toUpperCase()}
                  </span>
                </div>

                {/* Quick View Button */}
                <button
                  onClick={() => setActiveProjectModal(project)}
                  className="absolute bottom-4 right-4 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-blue-600 text-white text-xs font-semibold shadow-md opacity-90 group-hover:opacity-100 group-hover:scale-105 transition-all"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Project Preview</span>
                </button>
              </div>

              {/* Project Details Content */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-5">
                <div className="space-y-2.5">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white font-heading group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-slate-600 dark:text-slate-300 text-xs sm:text-sm leading-relaxed">
                    {project.description}
                  </p>
                </div>

                {/* Tech Badges */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 rounded-lg text-[11px] font-medium bg-blue-50/80 dark:bg-slate-700/60 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-slate-600/50"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Card Action Footer */}
                <div className="pt-4 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between gap-3">
                  <button
                    onClick={() => setActiveProjectModal(project)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors"
                  >
                    <span>View Details</span>
                    <Eye className="w-3.5 h-3.5" />
                  </button>

                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 transition-colors"
                    title="View GitHub Profile"
                  >
                    <Github className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Project Detail Modal */}
      {activeProjectModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-white dark:bg-slate-900 border border-blue-100 dark:border-slate-800 shadow-2xl p-6 sm:p-8 space-y-6">

            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                  {activeProjectModal.category} Project
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-heading mt-1">
                  {activeProjectModal.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveProjectModal(null)}
                className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Image Preview */}
            <div className="rounded-2xl overflow-hidden h-48 sm:h-56 bg-slate-900 border border-slate-200 dark:border-slate-800">
              <img
                src={activeProjectModal.image}
                alt={activeProjectModal.title}
                className="w-full h-full object-cover object-top"
              />
            </div>

            {/* Modal Description */}
            <div className="space-y-4">
              <h4 className="text-base font-bold text-slate-900 dark:text-white">Project Overview</h4>
              <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                {activeProjectModal.longDescription}
              </p>

              {/* Key Features List */}
              <div className="space-y-2 pt-2">
                <h5 className="text-xs font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider">Key Highlights & Features</h5>
                <ul className="space-y-2">
                  {activeProjectModal.keyFeatures.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-200">
                      <div className="p-0.5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-400 mt-0.5 shrink-0">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Tech Tags */}
              <div className="pt-2">
                <h5 className="text-xs font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider mb-2">Technologies Used</h5>
                <div className="flex flex-wrap gap-1.5">
                  {activeProjectModal.tags.map((tag) => (
                    <span key={tag} className="px-3 py-1 rounded-lg text-xs font-semibold bg-blue-50 dark:bg-slate-800 text-blue-600 dark:text-blue-400 border border-blue-100 dark:border-slate-700">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
              <a
                href={activeProjectModal.githubUrl}
                target="_blank"
                rel="noreferrer"
                className="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold text-xs sm:text-sm hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2"
              >
                <Github className="w-4 h-4" />
                <span>Visit GitHub Profile</span>
              </a>

              <button
                onClick={() => setActiveProjectModal(null)}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm shadow-md"
              >
                Close Preview
              </button>
            </div>

          </div>
        </div>
      )}
    </section>
  );
};
