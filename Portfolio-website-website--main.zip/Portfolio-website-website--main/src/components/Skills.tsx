import React, { useState } from 'react';
import { Code2, Server, Database, Sparkles, Search, CheckCircle2 } from 'lucide-react';

export const Skills: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'frontend' | 'backend' | 'database_tools'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const skillsData = [
    // Frontend & Design
    { name: 'HTML5', category: 'frontend', level: 95, tag: 'Proficient', experience: '6 Months', icon: '🌐' },
    { name: 'CSS3', category: 'frontend', level: 95, tag: 'Proficient', experience: '6 Months', icon: '🎨' },
    { name: 'JavaScript', category: 'frontend', level: 92, tag: 'Proficient', experience: '6 Months', icon: '⚡' },
    { name: 'React', category: 'frontend', level: 92, tag: 'Proficient', experience: '6 Months', icon: '⚛️' },
    { name: 'Tailwind CSS', category: 'frontend', level: 95, tag: 'Proficient', experience: '6 Months', icon: '🎨' },
    { name: 'Responsive Web Design', category: 'frontend', level: 95, tag: 'Proficient', experience: '6 Months', icon: '📱' },

    // Backend & API
    { name: 'Node.js', category: 'backend', level: 88, tag: 'Hands-On', experience: '6 Months', icon: '🟢' },
    { name: 'Express.js', category: 'backend', level: 90, tag: 'Hands-On', experience: '6 Months', icon: '🚂' },
    { name: 'REST APIs', category: 'backend', level: 92, tag: 'Hands-On', experience: '6 Months', icon: '🔌' },
    { name: 'AI / AI Tools', category: 'backend', level: 90, tag: 'Specialist', experience: '6 Months', icon: '🤖' },

    // Database & Tools
    { name: 'MongoDB', category: 'database_tools', level: 85, tag: 'Hands-On', experience: '6 Months', icon: '🍃' },
    { name: 'MySQL', category: 'database_tools', level: 84, tag: 'Hands-On', experience: '6 Months', icon: '🐬' },
    { name: 'Firebase', category: 'database_tools', level: 88, tag: 'Hands-On', experience: '6 Months', icon: '🔥' },
    { name: 'Git & GitHub', category: 'database_tools', level: 92, tag: 'Proficient', experience: '6 Months', icon: '🐙' },
  ];

  const filteredSkills = skillsData.filter((skill) => {
    const matchesCategory = activeCategory === 'all' || skill.category === activeCategory;
    const matchesSearch = skill.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const categoryTabs = [
    { id: 'all', label: 'All Stack', count: skillsData.length },
    { id: 'frontend', label: 'Frontend', count: skillsData.filter(s => s.category === 'frontend').length, icon: Code2 },
    { id: 'backend', label: 'Backend', count: skillsData.filter(s => s.category === 'backend').length, icon: Server },
    { id: 'database_tools', label: 'Databases & Tools', count: skillsData.filter(s => s.category === 'database_tools').length, icon: Database },
  ];

  return (
    <section id="skills" className="py-20 lg:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
            <Sparkles className="w-4 h-4" />
            <span>MY TECHNICAL STACK</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white font-heading tracking-tight">
            Skills & <span className="text-blue-600 dark:text-blue-500">Technologies</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg leading-relaxed">
            A comprehensive set of modern web development tools and technologies I use to craft high-quality digital experiences.
          </p>
        </div>

        {/* Filters Bar: Category Tabs + Live Search */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 max-w-4xl mx-auto mb-10 p-2 bg-white dark:bg-slate-800 rounded-2xl border border-blue-100 dark:border-slate-700 shadow-sm">
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
            {categoryTabs.map((tab) => {
              const isActive = activeCategory === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveCategory(tab.id as any)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all duration-200 flex items-center gap-2 whitespace-nowrap ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-500/25'
                      : 'text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-50 dark:hover:bg-slate-700/50'
                  }`}
                >
                  <span>{tab.label}</span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                    isActive ? 'bg-blue-700 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-300'
                  }`}>
                    {tab.count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search skill..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>
        </div>

        {/* Skill Cards Grid */}
        {filteredSkills.length === 0 ? (
          <div className="text-center py-12 text-slate-500 dark:text-slate-400 text-sm">
            No technologies match "{searchQuery}".
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredSkills.map((skill) => (
              <div
                key={skill.name}
                className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-blue-100 dark:border-slate-700 shadow-xs hover:shadow-md hover:border-blue-300 dark:hover:border-blue-600 transition-all duration-200 space-y-3 group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-slate-700 flex items-center justify-center text-xl group-hover:scale-110 transition-transform">
                      {skill.icon}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                        {skill.name}
                      </h3>
                      <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                        {skill.experience} practical experience
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400">
                      {skill.tag}
                    </span>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                    <span>Proficiency</span>
                    <span className="font-mono font-bold text-blue-600 dark:text-blue-400">{skill.level}%</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-blue-600 to-sky-400 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${skill.level}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};

