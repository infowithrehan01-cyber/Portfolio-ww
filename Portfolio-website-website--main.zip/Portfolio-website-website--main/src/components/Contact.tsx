import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, AlertCircle, Github, Facebook, Instagram, Copy, Check, Download, MessageSquare } from 'lucide-react';

interface ContactProps {
  onShowToast: (message: string, type: 'success' | 'error') => void;
}

export const Contact: React.FC<ContactProps> = ({ onShowToast }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    onShowToast(`Copied ${key} to clipboard!`, 'success');
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Full name is required';
    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    if (!formData.subject.trim()) newErrors.subject = 'Subject is required';
    if (!formData.message.trim()) {
      newErrors.message = 'Message content is required';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Message must be at least 10 characters long';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      onShowToast('Please correct the highlighted errors in the form.', 'error');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      onShowToast('Thank you! Your message has been sent successfully to Muhammad Rehan.', 'success');
      setFormData({ name: '', email: '', subject: '', message: '' });
      setErrors({});
    }, 1000);
  };

  const contactInfo = [
    {
      title: 'Email',
      value: 'infowithrehan01@gmail.com',
      href: 'mailto:infowithrehan01@gmail.com',
      copyValue: 'infowithrehan01@gmail.com',
      icon: Mail,
      subtext: 'Direct email contact',
    },
    {
      title: 'Phone / WhatsApp',
      value: '03026533848',
      href: 'https://wa.me/923026533848',
      copyValue: '03026533848',
      icon: Phone,
      subtext: 'Click to message on WhatsApp or Call',
    },
    {
      title: 'Location',
      value: 'Haroonabad, Pakistan',
      href: '#',
      copyValue: null,
      icon: MapPin,
      subtext: 'Local and remote projects',
    },
  ];

  return (
    <section id="contact" className="py-20 lg:py-28 bg-white/60 dark:bg-slate-900/40 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
            <Mail className="w-4 h-4" />
            <span>GET IN TOUCH</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white font-heading tracking-tight">
            Contact <span className="text-blue-600 dark:text-blue-500">Muhammad Rehan</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg leading-relaxed">
            Have a project in mind, website inquiry, or AI development goal? Get in touch directly!
          </p>
        </div>

        {/* Two Column Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">

          {/* Left Column: Contact Cards & Info (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="space-y-4">
              {contactInfo.map((info) => (
                <div
                  key={info.title}
                  className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-blue-100 dark:border-slate-700 shadow-md shadow-blue-500/5 hover:border-blue-300 dark:hover:border-blue-600 transition-all flex items-center justify-between gap-4 group"
                >
                  <a href={info.href} target={info.href.startsWith('http') ? '_blank' : '_self'} rel="noreferrer" className="flex items-start gap-4 flex-1">
                    <div className="p-3 rounded-xl bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400 group-hover:bg-blue-600 group-hover:text-white transition-colors shrink-0">
                      <info.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                        {info.title}
                      </h3>
                      <div className="text-sm sm:text-base font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                        {info.value}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        {info.subtext}
                      </div>
                    </div>
                  </a>

                  {info.copyValue && (
                    <button
                      onClick={() => copyToClipboard(info.copyValue!, info.title)}
                      className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 transition-colors shrink-0"
                      aria-label={`Copy ${info.title}`}
                      title={`Copy ${info.title}`}
                    >
                      {copiedKey === info.title ? (
                        <Check className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  )}
                </div>
              ))}
            </div>

            {/* Social Connect & CV Box */}
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-blue-100 dark:border-slate-700 shadow-md shadow-blue-500/5 space-y-4">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Connect & Download CV</h3>
              <div className="flex items-center gap-3">
                {[
                  { name: 'GitHub', icon: Github, href: 'https://github.com/infowithrehan01-cyber' },
                  { name: 'Facebook', icon: Facebook, href: 'https://www.facebook.com/share/1cVzLtmtvV/' },
                  { name: 'Instagram', icon: Instagram, href: 'https://www.instagram.com/chrehan89761437?stkn=b2E3NXhtdTV5ZmVi' },
                ].map((s) => (
                  <a
                    key={s.name}
                    href={s.href}
                    target="_blank"
                    rel="noreferrer"
                    className="p-3 rounded-xl bg-blue-50 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-100/80 transition-colors"
                    title={s.name}
                  >
                    <s.icon className="w-5 h-5" />
                  </a>
                ))}
              </div>

              {/* Prominent Download CV Button in Contact Section */}
              <div className="pt-2">
                <a
                  href="/Muhammad-Rehan-CV.pdf"
                  download="Muhammad-Rehan-CV.pdf"
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 transition-all"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Curriculum Vitae (PDF)</span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Contact Form (7 cols) */}
          <div className="lg:col-span-7">
            <form
              onSubmit={handleSubmit}
              className="p-7 sm:p-8 rounded-3xl bg-white dark:bg-slate-800/90 border border-blue-100 dark:border-slate-700 shadow-xl shadow-blue-500/5 space-y-5"
            >
              <h3 className="text-xl font-bold text-slate-900 dark:text-white font-heading">
                Send a Message
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {/* Full Name Input */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Ali Ahmed"
                    className={`w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border text-slate-900 dark:text-white text-sm focus:outline-none transition-colors ${
                      errors.name
                        ? 'border-red-500 focus:ring-1 focus:ring-red-500'
                        : 'border-slate-200 dark:border-slate-700 focus:border-blue-600 focus:ring-1 focus:ring-blue-600'
                    }`}
                  />
                  {errors.name && (
                    <p className="text-xs text-red-500 flex items-center gap-1 mt-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{errors.name}</span>
                    </p>
                  )}
                </div>

                {/* Email Input */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                    Your Email *
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="you@domain.com"
                    className={`w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border text-slate-900 dark:text-white text-sm focus:outline-none transition-colors ${
                      errors.email
                        ? 'border-red-500 focus:ring-1 focus:ring-red-500'
                        : 'border-slate-200 dark:border-slate-700 focus:border-blue-600 focus:ring-1 focus:ring-blue-600'
                    }`}
                  />
                  {errors.email && (
                    <p className="text-xs text-red-500 flex items-center gap-1 mt-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{errors.email}</span>
                    </p>
                  )}
                </div>
              </div>

              {/* Subject Input */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  Subject *
                </label>
                <input
                  type="text"
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  placeholder="e.g. AI Website Integration Inquiry"
                  className={`w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border text-slate-900 dark:text-white text-sm focus:outline-none transition-colors ${
                    errors.subject
                      ? 'border-red-500 focus:ring-1 focus:ring-red-500'
                      : 'border-slate-200 dark:border-slate-700 focus:border-blue-600 focus:ring-1 focus:ring-blue-600'
                  }`}
                />
                {errors.subject && (
                  <p className="text-xs text-red-500 flex items-center gap-1 mt-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errors.subject}</span>
                  </p>
                )}
              </div>

              {/* Message Input */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  Message *
                </label>
                <textarea
                  rows={5}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Describe your project requirements, website goals, or AI features..."
                  className={`w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border text-slate-900 dark:text-white text-sm focus:outline-none transition-colors ${
                    errors.message
                      ? 'border-red-500 focus:ring-1 focus:ring-red-500'
                      : 'border-slate-200 dark:border-slate-700 focus:border-blue-600 focus:ring-1 focus:ring-blue-600'
                  }`}
                />
                {errors.message && (
                  <p className="text-xs text-red-500 flex items-center gap-1 mt-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errors.message}</span>
                  </p>
                )}
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-md shadow-blue-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>Sending Message...</span>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Send Message</span>
                  </>
                )}
              </button>
            </form>
          </div>

        </div>

      </div>
    </section>
  );
};
