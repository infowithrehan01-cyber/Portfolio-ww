import React from 'react';
import { Star, Quote, MessageSquare, CheckCircle2 } from 'lucide-react';

export const Testimonials: React.FC = () => {
  const testimonials = [
    {
      quote: "Rehan delivered our SaaS web application weeks ahead of schedule. His attention to design detail, clean code structure, and responsive UI exceeded our expectations.",
      author: "Sarah Jenkins",
      role: "VP of Product",
      company: "CloudScale Inc.",
      rating: 5,
      initials: "SJ",
      gradient: "from-blue-600 to-indigo-600",
    },
    {
      quote: "Working with Rehan was an absolute pleasure. He transformed our complex database requirements into an intuitive, high-performance web dashboard with dynamic visual charts.",
      author: "Marcus Vance",
      role: "Co-Founder & CTO",
      company: "DataPulse AI",
      rating: 5,
      initials: "MV",
      gradient: "from-sky-500 to-blue-700",
    },
    {
      quote: "Rehan's full-stack expertise helped us scale our e-commerce store to thousands of daily users with zero downtime. Highly recommended for any serious web project!",
      author: "Elena Rostova",
      role: "E-Commerce Director",
      company: "Aura Retail",
      rating: 5,
      initials: "ER",
      gradient: "from-indigo-600 to-blue-600",
    },
  ];

  return (
    <section id="testimonials" className="py-20 lg:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
            <MessageSquare className="w-4 h-4" />
            <span>CLIENT TESTIMONIALS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white font-heading tracking-tight">
            What Clients <span className="text-blue-600 dark:text-blue-500">Say</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg leading-relaxed">
            Feedback from engineering leaders, product managers, and founders I've collaborated with.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, idx) => (
            <div
              key={idx}
              className="p-7 rounded-3xl bg-white dark:bg-slate-800/90 border border-blue-100/80 dark:border-slate-700/80 shadow-lg shadow-blue-500/5 hover:shadow-xl transition-all duration-300 flex flex-col justify-between space-y-6 relative group"
            >
              <Quote className="w-10 h-10 text-blue-100 dark:text-slate-700 absolute top-6 right-6 pointer-events-none group-hover:text-blue-200 dark:group-hover:text-slate-600 transition-colors" />

              <div className="space-y-4 relative z-10">
                {/* Rating Stars */}
                <div className="flex items-center gap-1">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>

                {/* Quote Text */}
                <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base leading-relaxed italic">
                  "{t.quote}"
                </p>
              </div>

              {/* Author Info */}
              <div className="flex items-center gap-3 pt-4 border-t border-slate-100 dark:border-slate-700/60">
                <div className={`w-11 h-11 rounded-full bg-gradient-to-br ${t.gradient} text-white font-bold text-sm flex items-center justify-center shadow-md shrink-0`}>
                  {t.initials}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white">{t.author}</h4>
                    <span title="Verified Client">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                    {t.role} · <span className="text-blue-600 dark:text-blue-400">{t.company}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

