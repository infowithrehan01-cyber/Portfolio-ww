import React from 'react';
import { Layout, Bot, Building2, ShoppingBag, Layers, RefreshCw, ArrowRight, CheckCircle2 } from 'lucide-react';

export const Services: React.FC = () => {
  const services = [
    {
      icon: Layout,
      title: 'Website Development',
      description: 'Crafting responsive, high-performance web applications with React, TypeScript, and modern CSS frameworks.',
      features: [
        'Single Page Applications (SPAs)',
        'Accessible & WCAG Compliant Layouts',
        'Optimized Load Times & Core Web Vitals',
        'Cross-Browser & Multi-Device Compatibility',
      ],
    },
    {
      icon: Bot,
      title: 'AI Website Integration',
      description: 'Embedding smart Gemini AI models, automated document processing, conversational assistants, and prompt workflows into web apps.',
      features: [
        'LLM & Gemini API Integration',
        'Streaming Text & Content Generation',
        'Smart Form Processing & Auto-complete',
        'Custom Prompt Engineering Architecture',
      ],
    },
    {
      icon: Building2,
      title: 'Business Websites',
      description: 'Building professional corporate portals, service directories, educational institutes, and healthcare booking systems.',
      features: [
        'Branded Professional Design',
        'Faculty, Service & Staff Directories',
        'Appointment Booking & Schedules',
        'Lead Capture & Contact Forms',
      ],
    },
    {
      icon: ShoppingBag,
      title: 'E-Commerce Development',
      description: 'Constructing high-converting online storefronts, cart drawers, product customization, and secure payment processing.',
      features: [
        'Custom Product Catalog & Filtering',
        'Shopping Cart & Checkout Flow',
        'Stripe & Online Payment Integration',
        'Inventory Management Interfaces',
      ],
    },
    {
      icon: Layers,
      title: 'Full-Stack Development',
      description: 'End-to-end full-stack engineering connecting client interfaces with scalable Node.js servers and databases.',
      features: [
        'Node.js & Express API Backend',
        'MongoDB, MySQL & PostgreSQL Schemas',
        'User Authentication & JWT Security',
        'Server Deployment & Cloud Integration',
      ],
    },
    {
      icon: RefreshCw,
      title: 'Website Improvements',
      description: 'Upgrading existing web applications with modern design redesigns, speed optimization, bug fixes, and feature additions.',
      features: [
        'Performance & Speed Audits',
        'Mobile Responsiveness Refactoring',
        'Legacy Code Modernization',
        'UI/UX Polish & Animation Upgrades',
      ],
    },
  ];

  return (
    <section id="services" className="py-20 lg:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
            <span>WHAT I OFFER</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white font-heading tracking-tight">
            Services & <span className="text-blue-600 dark:text-blue-500">Solutions</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg leading-relaxed">
            High-impact software engineering services tailored to bring your digital vision to life with precision and speed.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div
              key={service.title}
              className="p-7 rounded-3xl bg-white dark:bg-slate-800/90 border border-blue-100 dark:border-slate-700 shadow-md shadow-blue-500/5 hover:shadow-xl hover:border-blue-300 dark:hover:border-blue-600 transition-all duration-300 flex flex-col justify-between group"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300 shadow-sm">
                    <service.icon className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-mono font-semibold text-slate-400 dark:text-slate-500">
                    0{index + 1}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-slate-900 dark:text-white font-heading">
                  {service.title}
                </h3>

                <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                  {service.description}
                </p>

                {/* Features Checklist */}
                <div className="pt-3 space-y-2 border-t border-slate-100 dark:border-slate-700">
                  {service.features.map((feature) => (
                    <div key={feature} className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Service Footer CTA */}
              <div className="pt-6 mt-4">
                <a
                  href="#contact"
                  className="inline-flex items-center gap-2 text-xs font-bold text-blue-600 dark:text-blue-400 hover:text-blue-700 group-hover:translate-x-1 transition-transform"
                >
                  <span>Inquire About This Service</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
