import React from 'react';
import { Briefcase, GraduationCap, Calendar, CheckCircle2, MapPin } from 'lucide-react';

export const Experience: React.FC = () => {
  const experiences = [
    {
      role: 'AI Developer & Full-Stack Web Developer',
      company: 'Independent / Projects',
      location: 'Haroonabad, Pakistan',
      period: '6 Months Experience',
      type: 'Hands-on Development',
      description: 'Engineered 8 web applications and AI-powered digital tools focusing on clean design, responsive user interfaces, practical backend functionality, and modern web standards.',
      achievements: [
        'Built full-stack portals and e-commerce platforms using React, Node.js, Express, and MongoDB/MySQL',
        'Integrated AI models and smart features into modern responsive web interfaces',
        'Developed clean RESTful APIs and database schemas with Tailwind CSS styling',
      ],
      skills: ['AI / AI Tools', 'React', 'Node.js', 'Express.js', 'MongoDB', 'MySQL', 'Firebase', 'Tailwind CSS', 'Git & GitHub'],
    },
  ];

  const education = [
    {
      degree: 'BS Computer Science (BSCS)',
      institution: 'Government Degree College, Haroonabad',
      location: 'Haroonabad, Pakistan',
      period: 'Higher Education',
      details: 'Comprehensive study of computer science fundamentals, software engineering, algorithms, database management, and web application development.',
      highlights: ['Computer Science Major', 'Web & Software Development'],
    },
    {
      degree: 'F.Sc.',
      institution: 'Government Degree College, Haroonabad',
      location: 'Haroonabad, Pakistan',
      period: 'Intermediate Science',
      details: 'Pre-engineering science track focusing on mathematics, physics, and computer fundamentals.',
      highlights: ['Pre-Engineering / Science', 'Academic Foundation'],
    },
  ];

  return (
    <>
      {/* Experience Section */}
      <section id="experience" className="py-20 lg:py-28 bg-white/60 dark:bg-slate-900/40 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
              <Briefcase className="w-4 h-4" />
              <span>DEVELOPMENT JOURNEY</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white font-heading tracking-tight">
              Hands-On <span className="text-blue-600 dark:text-blue-500">Experience</span>
            </h2>
            <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg leading-relaxed">
              Practical experience in AI digital solutions and full-stack web development.
            </p>
          </div>

          {/* Timeline List */}
          <div className="relative pl-6 sm:pl-8 border-l-2 border-blue-200 dark:border-slate-700 space-y-10 max-w-4xl mx-auto">
            {experiences.map((exp, idx) => (
              <div key={idx} className="relative group">

                {/* Timeline Dot */}
                <div className="absolute -left-[31px] sm:-left-[39px] top-1.5 w-4 h-4 rounded-full bg-blue-600 border-4 border-white dark:border-slate-900 shadow-md group-hover:scale-125 transition-transform" />

                <div className="p-6 sm:p-7 rounded-3xl bg-white dark:bg-slate-800/90 border border-blue-100 dark:border-slate-700/80 shadow-md shadow-blue-500/5 space-y-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white font-heading">
                        {exp.role}
                      </h3>
                      <div className="text-sm font-semibold text-blue-600 dark:text-blue-400 mt-0.5 flex items-center gap-1.5">
                        <span>{exp.company}</span>
                        <span>·</span>
                        <span className="text-slate-500 font-normal flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {exp.location}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 dark:bg-slate-700 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-slate-600 flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{exp.period}</span>
                      </span>
                    </div>
                  </div>

                  <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                    {exp.description}
                  </p>

                  {/* Achievements Bullet List */}
                  <div className="space-y-2 pt-2">
                    <div className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      Key Focus Areas
                    </div>
                    <ul className="space-y-1.5">
                      {exp.achievements.map((ach, i) => (
                        <li key={i} className="flex items-start gap-2 text-xs sm:text-sm text-slate-700 dark:text-slate-200">
                          <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                          <span>{ach}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Skill Badges */}
                  <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-100 dark:border-slate-700">
                    {exp.skills.map((skill) => (
                      <span
                        key={skill}
                        className="px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-50 dark:bg-slate-700/50 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-600/50"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Dedicated Education Section */}
      <section id="education" className="py-20 lg:py-28 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
              <GraduationCap className="w-4 h-4" />
              <span>ACADEMIC BACKGROUND</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white font-heading tracking-tight">
              Education & <span className="text-blue-600 dark:text-blue-500">Qualifications</span>
            </h2>
            <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg leading-relaxed">
              Formal education and academic credentials from Government Degree College, Haroonabad.
            </p>
          </div>

          {/* Timeline List */}
          <div className="relative pl-6 sm:pl-8 border-l-2 border-blue-200 dark:border-slate-700 space-y-8 max-w-4xl mx-auto">
            {education.map((edu, idx) => (
              <div key={idx} className="relative group">

                {/* Timeline Dot */}
                <div className="absolute -left-[31px] sm:-left-[39px] top-1.5 w-4 h-4 rounded-full bg-blue-600 border-4 border-white dark:border-slate-900 shadow-md group-hover:scale-125 transition-transform" />

                <div className="p-6 sm:p-7 rounded-3xl bg-white dark:bg-slate-800/90 border border-blue-100 dark:border-slate-700/80 shadow-md shadow-blue-500/5 space-y-3">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <h3 className="text-lg font-bold text-slate-900 dark:text-white font-heading">
                        {edu.degree}
                      </h3>
                      <div className="text-sm font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-1 mt-0.5">
                        <span>{edu.institution}</span>
                      </div>
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 dark:bg-slate-700 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-slate-600">
                      {edu.location}
                    </span>
                  </div>

                  <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                    {edu.details}
                  </p>

                  <div className="flex flex-wrap gap-2 pt-2">
                    {edu.highlights.map((h) => (
                      <span key={h} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-blue-50/80 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-900/40">
                        <span>{h}</span>
                      </span>
                    ))}
                  </div>
                </div>

              </div>
            ))}
          </div>

        </div>
      </section>
    </>
  );
};

